int salva_end(int);
int pega_end();
int pega_atu();
